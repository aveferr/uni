#pragma once
#include <iostream>
#include <vector>
#include <algorithm>
#include "calc.h"
#include <math.h>
#include <random>
#include <numeric>
#include <fstream>
#include <limits>
#include <windows.h>
using namespace std;

StatisticalSample::StatisticalSample()
{
	a = 0;
	b = 0;
	n = 0;
}
vector<double> StatisticalSample::getSample()
{
	return samples;
}




double StatisticalSample::getAsymmetry()
{
	double numerator = 0; double denominator = 0;
	double average = getArithmeticMean();
	for (int i = 0; i < samples.size(); i++)
	{
		numerator = numerator + pow((samples[i] - average), 3);
		denominator = denominator + pow((samples[i] - average), 2);
	}

	return numerator / sqrt(pow(denominator, 3));
}

double StatisticalSample::getExcess()
{
	double numerator = 0; double denominator = 0;
	double average = getArithmeticMean();
	for (int i = 0; i < samples.size(); i++)
	{
		numerator = numerator + pow((samples[i] - average), 2);
		denominator = denominator + pow((samples[i] - average), 4);
	}

	return pow(numerator, 2) / denominator;
}

double StatisticalSample::getCorrelation(vector<double> other)
{
	double numerator = 0; double denominatorX = 0;  double denominatorY = 0;
	int min = samples.size() - other.size();
	if (min != 0)
		min = abs(min);
	else
		min = samples.size();
	double tmp;
	double average = getArithmeticMean(); double otherAverage = accumulate(other.begin(), other.end(), 0.0)/(double)other.size();
	for (int i = 0; i < min; i++)
	{
		numerator = numerator + (samples[i] - average) * (other[i] - otherAverage);
		denominatorX = denominatorX + pow((samples[i] - average), 2);
		denominatorY = denominatorY + pow((other[i] - otherAverage), 2);
	}
	return numerator / pow(denominatorX* denominatorY, 0.5);
}

void StatisticalSample::setA(double A)
{
	a = A;
}
void StatisticalSample::setB(double B)
{
	b = B;
}
void StatisticalSample::setN(int N)
{
	n = N;
}
double StatisticalSample::getA()
{
	return a;
}
double StatisticalSample::getB()
{
	return b;
}
double StatisticalSample::getMin()
{
	return samples[0];
}
double StatisticalSample::getMax()
{
	return samples[samples.size() - 1];
}
double StatisticalSample::getFirstQuartile()
{
	double quart = (double)samples.size() / 4;
	if (round(quart) == quart)
		return samples[quart - 1];
	else
		return samples[floor(quart) - 1] + abs((quart - floor(quart)) * (samples[floor(quart) - 1] - samples[floor(quart)]));
}
double StatisticalSample::getMedian()
{
	double median = (double)samples.size() / 2;
	if (round(median) == median)
		return (samples[median - 1] + samples[median]) / 2;
	else
		return samples[median - 1];
}
double StatisticalSample::getThirdQuartile()
{
	double quart = 3 * (double)samples.size() / 4;
	if (round(quart) == quart)
		return samples[quart - 1];
	else
		return samples[floor(quart) - 1] + abs((quart - floor(quart))* (samples[floor(quart) - 1] - samples[floor(quart)]));
}
double StatisticalSample::getArithmeticMean()
{
	double sum = accumulate(samples.begin(), samples.end(), 0.0);
	return sum / (double)samples.size();
}
double StatisticalSample::normalityTest()
{
	double N = (double)samples.size();
	double average = getArithmeticMean();
	double d; double haha = 0; double term1; double term2; 
	double s = 0; double koeffB = 0; double koeff_A_null = 0.899/pow((N - 2.4), 0.4162) - 0.02;
	for (int i = 0; i < samples.size(); i++)
	{
		s = s + pow(samples[i] - average, 2);
	}
	for (int i = 0; i < samples.size()/2; i++)
	{
		d = (N - 2 * ((double)i + 1) + 1) / (N - 0.5);
		koeffB = koeffB + koeff_A_null * (d + (1483 / pow((3 - d), 10.845)) +
			+ (71.6 * pow(10, -10) / pow((1.1 - d), 8.26))) * (samples[N - (i + 1)] - samples[i]);
	}
	
	double W = (1 - 0.6695 / pow(N, 0.6518)) * s / pow(koeffB, 2);
	return W;
}

double StatisticalSample::getDispersion()
{
	double dispersion = 0;
	double average = getArithmeticMean();
	for (int i = 0; i < samples.size(); i++)
	{
		dispersion = dispersion + pow((samples[i] - average), 2);
	}
	return dispersion / (double)samples.size();
}
void StatisticalSample::toFile()
{
	ofstream out(path);
	for (int i = 0; i < samples.size(); i++)
	{
		out << samples[i] << " " << '\n';
	}
	out.close();
}


void UniformDistribution::sampleFormation(double a, double b, int n)
{
	setA(a); setB(b); setN(n);
	samples.clear();
	random_device device;
	mt19937 generator(device());
	uniform_real_distribution<double> distribution(a, b);
	for (int i = 0; i < n; i++)
	{
		samples.push_back(distribution(generator));
	}
	sort(samples.begin(), samples.end());

}



void NormalDistribution::sampleFormation(double a, double b, int n)
{
	setA(a); setB(b); setN(n);
	samples.clear();
	double mean = (b - a) / 2;
	double dev = (b - a) / (2 * 3);
	double s;
	default_random_engine generator(time(0));
	normal_distribution<double> distribution(mean, dev);
	for (int i = 0; i < n; i++)
	{
		do
		{
			s = distribution(generator);
		} while (s < a && s > b);
		samples.push_back(s);
	}
	sort(samples.begin(), samples.end());
}

  

void RandomDistribution::sampleFormation(double a, double b, int n)
{
	setA(a); setB(b); setN(n);
	samples.clear();

	double rnd;
	random_device device;
	mt19937 generator(device());
	for (int i = 0; i < n; i++)
	{
		rnd = a + ((double)generator() / (double)(generator.max)()) * (b - a);
		samples.push_back(rnd);
	}
	sort(samples.begin(), samples.end());

}

void RandomDistribution::addElem(double value)
{
	samples.push_back(value);
	sort(samples.begin(), samples.end());
	setN(getSample().size() + 1);
	setB(samples[samples.size() - 1]);
	setA(samples[0]);

}

void RandomDistribution::delElem(int index)
{
	samples.erase(samples.begin() + index);
	setN(getSample().size() - 1);
	setB(samples[samples.size() - 1]);

}

void  RandomDistribution::fromFile()
{
	samples.clear();
	ifstream in(path); string line; string num;
	int i;
	while (getline(in, line))
	{
		i = 0; num = "";
		for(int i = 0; i < line.length(); i++)
		{
			if (line[i] != ' ')
			{
				num = num + line[i];
			}
			else
			{ 
				samples.push_back(stod(num));
				num = "";
			}

		}
		if (line[line.length() - 1] != ' ')
		{ 
			samples.push_back(stod(num));
			num = "";
		}
	}
	sort(samples.begin(), samples.end());
	setA(samples[0]); setB(samples[samples.size() - 1]); 
	setN(samples.size());
}



void InputError() 
{
	cin.clear();
	cin.ignore((numeric_limits<streamsize>::max)(), '\n');
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);
	cout << "�������� ����" << endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);

}
