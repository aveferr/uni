#pragma once
#include <iostream>
#include <vector>
#include <algorithm>

#include "string"
using namespace std;

class StatisticalSample
{
private:
    double a;
    double b;
    int n;
protected: 
    vector<double> samples;
    void setA(double a);
    void setB(double b);
    void setN(int n);
    string path = "file.txt";

public:
    StatisticalSample();
    vector<double> getSample();
    double getA();
    double getB();
    double getMin();
    double getMax();
    double getFirstQuartile();
    double getMedian();
    double getThirdQuartile();
    double getArithmeticMean();
    double getAsymmetry();
    double getExcess(); 
    double getCorrelation(vector<double> other);
    double normalityTest();
    double getDispersion();
    void toFile();
    virtual void sampleFormation(double a, double b, int n)  = 0;

};

class UniformDistribution : public StatisticalSample
{
public:
    void sampleFormation(double a, double b, int n);

};

class NormalDistribution : public StatisticalSample
{
public:
    void sampleFormation(double a, double b, int n);


};
class RandomDistribution : public StatisticalSample
{
public:
    void sampleFormation(double a, double b, int n);
    void addElem(double value);
    void delElem(int index);
    void fromFile();


};
    


void InputError();