﻿#include <iostream>
#include <random>
#include <vector>
#include <iomanip>
#include <Windows.h>
#include "calc.h"

using namespace std;

int main()
{
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	double a; double b; int n; string answer;
	char ans; int tmpans; double tmpvalue; int index; double normalityTest;
	UniformDistribution ud; NormalDistribution nd; RandomDistribution rd; 
	do
	{
		cout << "Выберите функцию" << '\n'
			<< '\t' << "a. Сформировать равномерную выборку" << '\n'
			<< '\t' << "b. Сформировать нормальную выборку" << '\n'
			<< '\t' << "c. Сформировать случайную выборку" << '\n'
			<< '\t' << "d. Считать выборку из файла" << '\n'
			<< '\t' << "e. Записать выборку в файл" << '\n'
			<< '\t' << "f. Вычислить статистические характеристики" << '\n'
			<< '\t' << "g. Вывод последней сформированной выборки" << '\n'
			<< '\t' << "h. Добавить элемент в выборку (только в случайную выборку)" << '\n'
			<< '\t' << "i. Удалить элемент из выборки (только в случайную выборку)" << '\n'
			<< '\t' << "j. Сравнение выборок (коэффициент корреляции)" << endl;
		cin >> answer;	ans = answer[0];

		if (cin.fail() || answer.length() > 1 || ans > 'j' || ans < 'a')
		{
			InputError();
			cout << "Введите еще раз" << endl;
		}
		switch (ans)
		{
		case 'a':
		{
			cout << "При формировании выборки, если такая уже есть предыдущая сотрется!" << endl;
			cout << "Введите промежуток (сначала a, потом b)" << endl;
			cin >> a;
			if (cin.fail())
			{
				InputError();
				break;
			}
			cin >> b;
			if (cin.fail() || b <= a)
			{
				InputError();
				break;
			}
			cout << "Введите количество элементов. Их должно быть не меньше 4!" << endl;
			cin >> n;
			if (cin.fail() || n <= 3)
			{
				InputError();
				break;
			}
			ud.sampleFormation(a, b, n);
			cout << "Выборка создана!" << endl;
			break;
		}
		case 'b':
		{
			cout << "Введите промежуток (сначала a, потом b)" << endl;
			cin >> a;
			if (cin.fail())
			{
				InputError();
				break;
			}
			cin >> b;
			if (cin.fail() || b <= a)
			{
				InputError();
				break;
			}
			cout << "Введите количество элементов. Их должно быть не меньше 4!" << endl;
			cin >> n;
			if (cin.fail() || n <= 3)
			{
				InputError();
				break;
			}
			nd.sampleFormation(a, b, n);
			cout << "Выборка создана!" << endl;
			break;
		}
		case 'c':
		{
			cout << "Введите промежуток (сначала a, потом b)" << endl;
			cin >> a;
			if (cin.fail())
			{
				InputError();
				break;
			}
			cin >> b;
			if (cin.fail() || b <= a)
			{
				InputError();
				break;
			}
			cout << "Введите количество элементов. Их должно быть не меньше 4!" << endl;
			cin >> n;
			if (cin.fail() || n <= 3)
			{
				InputError();
				break;
			}
			rd.sampleFormation(a, b, n);
			cout << "Выборка создана!" << endl;
			break;
		}
		case 'd':
		{
			rd.fromFile();
			cout << "Выборка считана!" << endl;
			break;

		}
		case 'e':
		{
			cout << "Выберите выборку:" << '\n'
				<< '\t' << "1. Равномерная" << '\n'
				<< '\t' << "2. Нормальная" << '\n'
				<< '\t' << "3. Случайная" << endl;

			cin >> tmpans;
			if (cin.fail() || tmpans > 3 || tmpans < 1)
			{
				InputError();
				break;
			}
			switch (tmpans)
			{
			case 1:
				if (ud.getSample().size() != 0)
				{
					cout << "Предыдущая выборка в файле будет удалена!" << endl;
					ud.toFile();
					cout << "Выборка записана в файл!" << endl;
				}
				else
					cout << "Сначала создайте выборку" << endl;
				break;
			case 2:
				if (nd.getSample().size() != 0)
				{
					cout << "Предыдущая выборка в файле будет удалена!" << endl;
					nd.toFile();
					cout << "Выборка записана в файл!" << endl;
				}
				else
					cout << "Сначала создайте выборку" << endl;
				break;
			case 3:
				if (rd.getSample().size() != 0)
				{
					cout << "Предыдущая выборка в файле будет удалена!" << endl;
					rd.toFile();
					cout << "Выборка записана в файл!" << endl;
				}
				else
					cout << "Сначала создайте выборку" << endl;
				break;
			}
			break;
		}

		case 'f':
			cout << "Выберите выборку:" << '\n'
				<< '\t' << "1. Равномерная" << '\n'
				<< '\t' << "2. Нормальная" << '\n'
				<< '\t' << "3. Случайная" << endl;

			cin >> tmpans;
			if (cin.fail() || tmpans > 3 || tmpans < 1)
			{
				InputError();
				break;
			}
			switch (tmpans)
			{
			case 1:
				if (ud.getSample().size() > 3)
				{
					normalityTest = ud.normalityTest();
					cout << "Характеристики выборки: " << endl;
					cout << '\t' << "Минимальный элемент выборки: " << ud.getMin() << endl;
					cout << '\t' << "Максимальный элемент выборки: " << ud.getMax() << endl;
					cout << '\t' << "Первый квартиль: " << ud.getFirstQuartile() << endl;
					cout << '\t' << "Второй квартиль (т. е. медиана): " << ud.getMedian() << endl;
					cout << '\t' << "Третий квартиль: " << ud.getThirdQuartile() << endl;
					cout << '\t' << "Среднее арифметическое: " << ud.getArithmeticMean() << endl;
					cout << '\t' << "Коэффициент асимметрии: " << ud.getAsymmetry() << endl;
					cout << '\t' << "Коэффициент эксцесса: " << ud.getExcess() << endl;
					cout << '\t' << "Дисперсия " << ud.getDispersion() << endl;
					cout << '\t' << "Тест на нормальность (критерий Шапиро-Уилка): " << normalityTest << endl;
					if (normalityTest < 1)
						cout << '\t \t' << "Выборка подчиняется нормальному распределению" << endl;
					else
						cout << "\t \t " << "Выборка не подчиняется нормальному распределению" << endl;
					break;;
				}
				else
				{
					cout << "Сначала создайте выборку, у которой больше трех элементов!" << endl;
					break;
				}
			case 2:
				if (nd.getSample().size() > 3)
				{
					normalityTest = nd.normalityTest();

					cout << "Характеристики выборки: " << endl;
					cout << '\t' << "Минимальный элемент выборки: " << nd.getMin() << endl;
					cout << '\t' << "Максимальный элемент выборки: " << nd.getMax() << endl;
					cout << '\t' << "Первый квартиль: " << nd.getFirstQuartile() << endl;
					cout << '\t' << "Второй квартиль (т. е. медиана): " << nd.getMedian() << endl;
					cout << '\t' << "Третий квартиль: " << nd.getThirdQuartile() << endl;
					cout << '\t' << "Среднее арифметическое: " << nd.getArithmeticMean() << endl;
					cout << '\t' << "Коэффициент асимметрии: " << nd.getAsymmetry() << endl;
					cout << '\t' << "Коэффициент эксцесса: " << nd.getExcess() << endl;
					cout << '\t' << "Дисперсия " << nd.getDispersion() << endl;
					cout << '\t' << "Тест на нормальность(критерий Шапиро - Уилка) : " << normalityTest << endl;
					if (normalityTest < 1)
						cout << "Выборка подчиняется нормальному распределению" << endl;
					else
						cout << "Выборка не подчиняется нормальному распределению" << endl;
					break;
				}
				else
				{
					cout << "Сначала создайте выборку, у которой больше трех элементов!" << endl;
					break;
				}
			case 3:
				if (rd.getSample().size() > 3)
				{
					normalityTest = rd.normalityTest();
					cout << "Характеристики выборки: " << endl;
					cout << '\t' << "Минимальный элемент выборки: " << rd.getMin() << endl;
					cout << '\t' << "Максимальный элемент выборки: " << rd.getMax() << endl;
					cout << '\t' << "Первый квартиль: " << rd.getFirstQuartile() << endl;
					cout << '\t' << "Второй квартиль (т. е. медиана): " << rd.getMedian() << endl;
					cout << '\t' << "Третий квартиль: " << rd.getThirdQuartile() << endl;
					cout << '\t' << "Среднее арифметическое: " << rd.getArithmeticMean() << endl;
					cout << '\t' << "Коэффициент асимметрии: " << rd.getAsymmetry() << endl;
					cout << '\t' << "Коэффициент эксцесса: " << rd.getExcess() << endl;
					cout << '\t' << "Дисперсия " << rd.getDispersion() << endl;
					cout << '\t' << "Тест на нормальность (критерий Шапиро-Уилка): " << normalityTest << endl;
					if (normalityTest < 1)
						cout << "Выборка подчиняется нормальному распределению" << endl;
					else
						cout << "Выборка не подчиняется нормальному распределению" << endl;
					break;
				}
				else
				{
					cout << "Сначала создайте выборку, у которой больше трех элементов!" << endl;
					break;
				}

			}
			break;
		case 'g':
		{
			cout << "Выберите выборку:" << '\n'
				<< '\t' << "1. Равномерная" << '\n'
				<< '\t' << "2. Нормальная" << '\n'
				<< '\t' << "3. Случайная" << endl;
			cin >> tmpans;
			if (cin.fail() || tmpans > 3 || tmpans < 1)
			{
				InputError();
				break;
			}
			switch (tmpans)
			{
			case 1:
				if (ud.getSample().size() != 0)
				{
					cout << "{";
					for (int i = 0; i < ud.getSample().size() - 1; i++)
					{
						cout << ud.getSample()[i] << ", ";
					}
					cout << ud.getSample()[ud.getSample().size() - 1] << "}" << endl; break;
				}
				else
				{
					cout << "Сначала создайте выборку!" << endl;
					break;
				}
			case 2:
				if (nd.getSample().size() != 0)
				{
					cout << "{";
					for (int i = 0; i < nd.getSample().size() - 1; i++)
					{
						cout << nd.getSample()[i] << ", ";
					}
					cout << nd.getSample()[nd.getSample().size() - 1] << "}" << endl; break;
				}
				else
				{
					cout << "Сначала создайте выборку!" << endl;
					break;
				}
			case 3:
				if (rd.getSample().size() != 0)
				{
					cout << "{";
					for (int i = 0; i < rd.getSample().size() - 1; i++)
					{
						cout << rd.getSample()[i] << ",  ";
					}
					cout << rd.getSample()[rd.getSample().size() - 1] << "}" << endl; break;
				}
				else
				{
					cout << "Сначала создайте выборку!" << endl;
					break;
				}
			}
			break;

		}
		case 'h':
		{
			cout << "Введите значение" << endl;
			cin >> tmpvalue;
			if (cin.fail())
			{
				InputError();
				break;
			}
			rd.addElem(tmpvalue);
			cout << "Элемент добавлен" << endl;
			break;
		}
		case 'i':
		{
			if (rd.getSample().size() == 0)
			{
				cout << "В этой выборке ни одного элемента!" << endl;
				break;
			}
			if (rd.getSample().size() == 1)
			{
				cout << "В выборке один элемент, будет удален он." << endl;
				rd.delElem(0);
				cout << "Элемент добавлен" << endl;
				break;
			}
			else
			{
				cout << "Введите индекс от 1 до " << rd.getSample().size() << endl;
				cin >> index;
				if (cin.fail() || index > rd.getSample().size() || index < 0)
				{
					InputError();
					break;
				}
				rd.delElem(index - 1);
				cout << "Элемент добавлен" << endl;
				break;
			}
		}
		case 'j':
		{
			cout << "Если в одной выборке элементов больше, чем в другой, то последние (самые большие по значению) элементы в бОльшей выборке не будут учитываться" << endl;
			cout << "Выберите первую выборку:" << '\n'
				<< '\t' << "1. Равномерная" << '\n'
				<< '\t' << "2. Нормальная" << '\n'
				<< '\t' << "3. Случайная" << endl;
			cin >> tmpans;
			if (cin.fail() || tmpans > 3 || tmpans < 1)
			{
				InputError();
				break;
			}
			switch (tmpans)
			{
			case 1:
				if (ud.getSample().size() > 3)
				{
					cout << "Выберите вторую выборку:" << '\n'
						<< '\t' << "1. Нормальная" << '\n'
						<< '\t' << "2. Случайная" << endl;
					cin >> tmpans;
					if (cin.fail() || tmpans > 2 || tmpans < 1)
					{
						InputError();
						break;
					}
					switch (tmpans)
					{
					case 1:
						if (nd.getSample().size() > 3)
							cout << "Коэффициент корреляции: " << ud.getCorrelation(nd.getSample()) << endl;
						else
							cout << "Сначала создайте выборку с нормальным распределение!" << endl;
						break;
					case 2:
						if (rd.getSample().size() > 3)
							cout << "Коэффициент корреляции: " << rd.getCorrelation(rd.getSample()) << endl;
						else
							cout << "Сначала создайте выборку со случайным распределением!" << endl;
						break;
					}
				}
				else
				{
					cout << "Сначала создайте равномерную выборку!" << endl;
				}
				break;
			case 2:
				if (nd.getSample().size() > 3)
				{
					cout << "Выберите вторую выборку:" << '\n'
						<< '\t' << "1. Равномерная" << '\n'
						<< '\t' << "2. Случайная" << endl;
					cin >> tmpans;
					if (cin.fail() || tmpans > 2 || tmpans < 1)
					{
						InputError();
						break;
					}
					switch (tmpans)
					{
					case 1:
						if (ud.getSample().size() > 3)
							cout << "Коэффициент корреляции: " << ud.getCorrelation(nd.getSample()) << endl;
						else
							cout << "Сначала создайте выборку с равномерным распределением!" << endl;
						break;
					case 2:
						if (rd.getSample().size() > 3)
							cout << "Коэффициент корреляции: " << ud.getCorrelation(rd.getSample()) << endl;
						else
							cout << "Сначала создайте выборку со случайным распределением!" << endl;
						break;
					}
				}
				else
				{
					cout << "Сначала создайте выборку с нормальным распределением!" << endl;
				}
				break;
			case 3:
				if (rd.getSample().size() > 3)
				{
					cout << "Выберите вторую выборку:" << '\n'
						<< '\t' << "1. Равномерная" << '\n'
						<< '\t' << "2. Нормальная" << endl;
					cin >> tmpans;
					if (cin.fail() || tmpans > 2 || tmpans < 1)
					{
						InputError();
						break;
					}
					switch (tmpans)
					{
					case 1:
						if (ud.getSample().size() > 3)
							cout << "Коэффициент корреляции: " << ud.getCorrelation(nd.getSample()) << endl;
						else
							cout << "Сначала создайте выборку с равномерным распределением!" << endl;
						break;
					case 2:
						if (nd.getSample().size() > 3)
							cout << "Коэффициент корреляции: " << ud.getCorrelation(rd.getSample()) << endl;
						else
							cout << "Сначала создайте выборку с нормальным распределением!" << endl;
						break;
					
					}
				}
				else
					cout << "Сначала создайте случайную выборку!" << endl;
				break;
			
			}
			break;

			
		}
		}
	} while (true);
}
